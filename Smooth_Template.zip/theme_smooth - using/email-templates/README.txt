Make sure to run all of your email template HTML through a style inliner. This will help ensure your email template appears the same in all mail services. 

The Zurb Foundation provides a great and free CSS Inliner called Ink: http://zurb.com/ink/inliner.php